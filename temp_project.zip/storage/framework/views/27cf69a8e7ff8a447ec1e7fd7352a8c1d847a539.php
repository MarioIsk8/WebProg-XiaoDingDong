

<?php $__env->startSection('title','XIAO DING DONG | HOME'); ?>

<?php $__env->startSection('content'); ?>
<style>
    tbody{
        background-color: lightslategrey;
        color:azure;
        text-align: center;
    }

    thead{
        background-color: black;
        color: gold;
        text-align: center;
    }
</style>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8 text-center">
            <div class="py-4">
                <h2 style="color:gold; font-weight:bold;">交易记录 | Transaction History</h2>
            </div>

            <?php if($transactions_headers->isNotEmpty()): ?>
                <div class="container">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Transaction ID</th>
                                <th>Purchase Date</th>
                                <th>Food Name</th>
                                <th>Total Price</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $transactions_headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($transaction->transaction_id); ?></td>
                                    <td><?php echo e($transaction->purchase_date); ?></td>
                                    <td><?php echo e($transaction->food_name); ?></td>
                                    <td><?php echo e($transaction->total_price); ?></td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="text-center" style="background-color: black;">
                    <h3 style="color:gold; font-weight:bold">There are no transactions yet...</h3>
                    <h5 style="color: azure;">Poof! Transaction history gone. Time to make delicious memories all over again. Let's fill this blank page with savory stories and culinary adventures. Bon appétit!</h5>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('../components/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Mario\Main Data\Kuliah\Semester 5\Web Programming\LAB\Project_LAB\mario_project_lab\resources\views/history.blade.php ENDPATH**/ ?>