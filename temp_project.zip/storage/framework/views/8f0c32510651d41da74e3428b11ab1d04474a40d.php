<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>
<body style="background-image: url(/assets/download.jpg); min-height: 100vh; overflow: hidden">

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
        <a class="navbar-brand" href="#">Navbar</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav">
                <a class="nav-link active" aria-current="page" href="#">Home</a>
                 <?php if(auth()->guard()->check()): ?>
                    <?php if(!Gate::allows('admin')): ?>
                        <a class="nav-link active" href="/search">Search Food</a>
                        <a class="nav-link active" href="/cart">Cart</a>
                    <?php else: ?>
                        <a class="nav-link active" href="/add">Add New Food</a>
                        <a class="nav-link active" href="/manage">Manage Food</a>

                    <a class="nav-link active dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false`">
                        Welcome, <?php echo e(auth()->user()->name); ?>

                    <?php endif; ?>


                <?php endif; ?>


            </div>
        </div>
        </div>
        <div class="collapse navbar-collapse d-flex justify-content-end" id="navbarNavAltMarkup">
            <div class="navbar-nav">
                    <?php if(auth()->guard()->check()): ?>
                        <ul class="nav-link active" aria-labelledby="navbarDropdownMenuLink">
                            <li><a class="dropdown-item" href="/profile">Profile</a></li>
                            <li><a class="dropdown-item" href="/history">Transaction History</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="/logout">Sign Out</a></li>
                        </ul>
                    <?php endif; ?>
                    <?php if(auth()->guard()->guest()): ?>
                    <div class="collapse navbar-collapse" id="navbarNavDropdown">
                        <ul class="navbar-nav">
                            <li class="nav-item me-3">
                                <a class="nav-link active " href="/login">Login</a>
                            </li>
                            <li class="nav-item me-3">
                                <a class="nav-link active " href="/register">Register</a>
                            </li>
                        </ul>
                    </div>
                        
                    <?php endif; ?>
            </div>
        </div>
        </div>
    </nav>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">XiAO DiNG DoNG</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav d-flex justify-content-end">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="/">Home</a>
                    </li>





                </ul>
            </div>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav">
                </ul>
            </div>
        </div>
    </nav>
    

<?php echo $__env->yieldContent('content'); ?>


</body>
</html>
<?php /**PATH D:\Mario\Main Data\Kuliah\Semester 5\Web Programming\LAB\Project_LAB\project_lab\resources\views////components/master.blade.php ENDPATH**/ ?>