<?php $__env->startSection('title','XIAO DING DONG | MANAGE FOOD'); ?>

<style>
    .hidden {
        display: none;
    }
</style>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-column justify-center text-warning" style="width: 80%; gap: 2rem; margin-top: 2rem;">

    <h2 style="color:gold; font-weight:bold;">管理食物 | Manage Foods</h2>

    <div>
        <form class="d-flex" role="search" method="GET" action="<?php echo e(route('managefood.search')); ?>" style="max-width: 600px;">
            <input class="form-control me-2" type="search" name="food_name" placeholder="Search Here..." aria-label="Search" style="flex: 1;">
            <button class="btn btn-outline-success text-light" type="submit" style="background-color: black; color:azure;">Search</button>
        </form>

        <div id="filterForm" class="d-flex" role="search" style="background-color:black; color:azure; font-weight:bold; max-width: fit-content; padding: 0 10px 0 10px;" method="GET" action="<?php echo e(route('managefood.filter')); ?>">
            <h5 style="margin: 3px;">Filter Category</h5>
            <input type="checkbox" id="main_course" class="filterCheckbox" value="Main Course" style="margin-left: 20px;">
            <label for="main_course" style="margin: 3px;">Main Course</label>

            <input type="checkbox" id="beverages" class="filterCheckbox" value="Beverages" style="margin-left: 20px;">
            <label for="beverages" style="margin: 3px;">Beverage</label>

            <input type="checkbox" id="dessert" class="filterCheckbox" value="Dessert" style="margin-left: 20px;">
            <label for="dessert" style="margin: 3px;">Dessert</label>
        </div>
    </div>




    <div class="container mt-3" style="min-height: fit-content;">
        <div class="row" style="max-height: fit-content">
            <?php $__empty_1 = true; $__currentLoopData = $foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php if($food->food_cat=='Main Course'): ?>
                    <div class="col-md-3 mb-3 main-course">
                <?php elseif($food->food_cat=='Beverages'): ?>
                    <div class="col-md-3 mb-3 beverages">
                <?php else: ?>
                    <div class="col-md-3 mb-3 dessert">
                <?php endif; ?>

                    <div class="card h-200" style="width: 100%; background-color:black; height: 600px;">
                        <img src="<?php echo e(asset('images/'.$food->berkas)); ?>" class="card-img-top" alt="..." style="height: 200px; object-fit: cover;">
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title mb-2" style="font-weight: bold; color:gold"><?php echo e($food->food_name); ?></h5>
                            <h6 style="font-weight: bold; color:azure;">Category</h6>
                            <p class="card-text mb-2" style="flex-grow: 1; overflow: hidden; text-overflow: ellipsis; color:azure;"><?php echo e($food->food_cat); ?></p>
                            <h6 style="font-weight: bold; color:azure;">Description</h6>
                            <p class="card-text mb-2" style="flex-grow: 1; overflow: hidden; text-overflow: ellipsis; color:azure;"><?php echo e($food->desc); ?></p>
                            <?php if(auth()->guard()->check()): ?>
                                <?php if(auth()->user()->role=='admin'): ?>
                                    <a href="/managefood/<?php echo e($food->id); ?>/edit"><button type="submit" class="btn btn-warning mt-2"  style="text-align: center; background-color: darkgray; color:azure;">Update</button></a>
                                    <form action="<?php echo e(route('managefood.destroy', $food)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-warning mt-2" style="text-align: center; background-color: red; color:azure;">
                                            <i class="bi bi-trash" style="border:azure;"></i> Delete
                                        </button>
                                    </form>
                                <?php endif; ?>
                            <?php endif; ?>

                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <td colspan="6" class="text-center" style="background-color: grey;">
                    <h4 style="color: azure; text-align:center; background-color:darkgray;">Food is not available</h4>
                </td>
            <?php endif; ?>
        </div>
    </div>
</div>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const checkboxes = document.querySelectorAll('.filterCheckbox');
        checkboxes.forEach(function (checkbox) {
            checkbox.addEventListener('change', function () {
                updateDisplay();
            });
        });

        function updateDisplay() {
            let anyCheckboxChecked = false;

            checkboxes.forEach(function (checkbox) {
                const className = checkbox.value.toLowerCase().replace(' ', '-');
                const elements = document.querySelectorAll('.' + className);

                if (checkbox.checked) {
                    anyCheckboxChecked = true;
                    elements.forEach(function (element) {
                        element.style.display = 'block';
                    });
                } else {
                    elements.forEach(function (element) {
                        element.style.display = 'none';
                    });
                }
            });

            if (!anyCheckboxChecked) {
                const allElements = document.querySelectorAll('.col-md-3');
                allElements.forEach(function (element) {
                    element.style.display = 'block';
                });
            }
        }

        updateDisplay();
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('../components/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Mario\Main Data\Kuliah\Semester 5\Web Programming\LAB\Project_LAB\mario_project_lab\resources\views/managefood.blade.php ENDPATH**/ ?>